class MyProperties:
    def __init__(self):
        self.default_value = 12
        